#include <stdio.h>
#include <unistd.h>
#include <netdb.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#define PORT 8080
#define MAX 80
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <net/if.h>


char buff[MAX];


//display ip
void ip(){
printf("hiiiiiiiiiiiiiiiiiiiiiiiii\n");

char hostbuffer[256];
char *IP;
struct hostent *host_entry;
int hostname;
//Retrieve hostname
hostname = gethostname(hostbuffer, sizeof(hostbuffer));

//Retrieve host information
host_entry = gethostbyname(hostbuffer);

//convert an internet network address into ASCII string
IP = inet_ntoa(*((struct in_addr*)host_entry->h_addr_list[0]));

printf("IP: %s", IP);

}

//client function
void clientside(int server_socket){
int n;

for(;;){
	bzero(buff, sizeof(buff));
	printf("Enter message: ");
	n=0;
	while ((buff[n++] = getchar()) != '\n')
	;
	write(server_socket, buff, sizeof(buff));
	bzero(buff, sizeof(buff));
	read(server_socket, buff, sizeof(buff));
	printf("From Server : %s", buff);
	if((strncmp(buff, "exit", 4)) == 0){
	printf("Client Exit \n");
	break;
}

}
}


//function to chat between client and server
void chatfunc(int server_socket){
//char buff[MAX];
int n;

//loop
for(;;){
bzero(buff, MAX);

//read message from client and copy it to buffer
read(server_socket, buff, sizeof(buff));

//print buffer
printf("From client: %s\t To client: ", buff);
bzero(buff,MAX);
n=0;

//copy server message in the buffer
while((buff[n++] = getchar()) != '\n'){
;
}

// send the buffer to client
write(server_socket, buff, sizeof(buff));

//if msg contrains "Exit" then server exit and chat end
if(strncmp("exit", buff, 4) == 0){
printf("Server Exit.\n");
break;
}

}
}

int main(){

int server_socket, connt, clientlen;
struct sockaddr_in server_addr, client;
int destination, portno;


//create socket and verification
server_socket = socket(AF_INET, SOCK_STREAM, 0);
if (server_socket < 0){
//return err_msg_ERR("Cannot create socket");
printf("Socket failed to create");
exit(0);
}
else{
//Socket created
printf("Socket created\n");
bzero(&server_addr, sizeof(server_addr));
}

server_addr.sin_family = AF_INET;
server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
server_addr.sin_port = htons(PORT);

if(bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0 ){
//return err_msg_ERR("Bind failed");
printf("Bind failed\n");
}
else{
printf("Socket binded successfully\n");
}




int choice;
int done = 0;
while(done != 9999){
printf("1. help\n");
printf("2. myip\n");
printf("3. myport\n");
printf("4. connect\n");
printf("5. list\n");
printf("6. terminate\n");
printf("7. send\n");
printf("8. exit\n");

scanf("%d", &choice);

switch(choice){
case 1: printf("2. myip: Display IP address of the process.\n");
	printf("3. myport: Display the port on which the process is listening for incoming connections.\n");
	printf("4. connect: Connect to specified <destination> at the specified <port no>\n");
	printf("5. list: Display a numbered list of all the connections the process is part of.\n");
	printf("6. terminate: Terminate the connection listed under the specified number when LIST is used to display all connections.\n");
	printf("7. send: Send message to the host of the connect that is designated by the number 3 when command 'list' is used.\n");
	printf("8. exit: Close all connections and terminate the process.\n");
	break;
case 2: //printf("myip");
	ip();
	break;
case 3: printf("myport");
	break;
case 4: printf("connect <destination> <port no>\n");
	printf("Destination location");
	scanf("%d", &destination);
	printf("Port no");
	scanf("%d", &portno);
	clientside(server_socket);
	close(server_socket);
	break;
case 5: printf("list");
	break;
case 6: printf("ter");
	break;
case 7: printf("se");
	break;
case 8: printf("ex");
	done = 9999;
	break;
}
}
/*
//create socket and verification
server_socket = socket(AF_INET, SOCK_STREAM, 0);
if (server_socket < 0){
//return err_msg_ERR("Cannot create socket");
printf("Socket failed to create");
exit(0);
}
else{
//Socket created
printf("Socket created\n");
bzero(&server_addr, sizeof(server_addr));
}

server_addr.sin_family = AF_INET;
server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
server_addr.sin_port = htons(PORT);

//printf("Port: %d:", ntohs(server_addr.sin_port));


//Bind the new created socket to given IP and verification
if(bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0 ){
//return err_msg_ERR("Bind failed");
printf("Bind failed\n");
}
else{
printf("Socket binded successfully\n");
}

*/



//Server is ready to listen
if(listen(server_socket, 5) < 0){
printf("Unable to listen on port %d\n", PORT);
exit(0);
}
else{
printf("Server is listening\n");
clientlen = sizeof(client);
}

//Accept the data packet from client and verification
connt = accept(server_socket, (struct sockaddr *)&client, &clientlen);

if(connt < 0){
printf("server accept failed..\n");
exit(0);
}
else{
printf("Server accept the client...\n");
}

//function to chat
chatfunc(connt);

//close the socket
close(server_socket);


}
